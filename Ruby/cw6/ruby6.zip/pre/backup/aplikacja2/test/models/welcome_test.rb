require 'test_helper'

class WelcomeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
