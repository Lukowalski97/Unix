class Welcome < ApplicationRecord
    belongs_to :category # Komunikat powitalny należy do określonej kategorii
  end
